# 입력 데이터

Kaggle의 [Home Credit Default Risk](https://www.kaggle.com/c/home-credit-default-risk)에서 [데이터](https://www.kaggle.com/c/home-credit-default-risk/data)를 다운로드하고, 이 디렉터리 내부에 배치해주세요.
다운로드한 파일은 ".csv.zip"이므로, 압축을 해제해서 사용해주세요.

```
input
└── home-credit-default-risk
    |── application_train.csv
    └── bureau.csv
```
