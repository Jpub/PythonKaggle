# 입력 데이터

[데이터](https://www.kaggle.com/sishihara/submit-files)를 다운로드하고, 이 디렉터리 내부에 배치해주세요.

```
input
└── submit-files
    |── submission_lightgbm_holdout.csv
    |── submission_lightgbm_skfold.csv
    └── submission_randomforest.csv
```
