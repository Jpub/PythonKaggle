# 입력 데이터

Kaggle의 [Titanic: Machine Learning from Disaster](https://www.kaggle.com/c/titanic)에서 [데이터](https://www.kaggle.com/c/titanic/data)를 다운로드하고, 이 디렉터리 내부에 배치해주세요.

```
input
└── titanic
    |── train.csv
    |── test.csv
    └── gender_submission.csv
```
